from setuptools import setup

setup(
    name='packagetest',
    version='1.0',
    packages=['package'],
    url='https://github.com/Elyesbdakhlia',
    download_url = 'https://github.com/Elyesbdakhlia/API-SDK/archive/refs/tags/1.0.tar.gz',
    license='',
    author='ASUS',
    author_email='elyes@laevitas.ch',
    description='Sdk'
)
