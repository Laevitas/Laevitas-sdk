# API-SDK
First test version includes 7 endpoints:
